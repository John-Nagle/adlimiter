# adlimiter
Ad Limiter browser add-on

Port from old Jetpack API version completed.
