//  Rates all search results using SiteTruth rating system.
//
//  J. Nagle        
//  SiteTruth
//  October, 2017
//
//  WebExtensions version.
//
//  Starts the content script
//
"use strict";                                           // strict mode  
//  Enable site rating
startcontentscript(KSEARCHENGINES);                                               
